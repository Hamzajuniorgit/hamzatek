// src/pages/Home.js
import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Welcome to the eLearning Platform
        </h1>
        <p className="text-gray-600 mb-8">
          Learn at your own pace with courses from top instructors.
        </p>
        <div className="space-x-4">
          <Link
            to="/login"
            className="px-6 py-3 bg-blue-500 text-white rounded-md shadow-md hover:bg-blue-600"
          >
            Login
          </Link>
          <Link
            to="/register"
            className="px-6 py-3 bg-green-500 text-white rounded-md shadow-md hover:bg-green-600"
          >
            Register
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Home;
