import axiosInstance from "./axiosInstance";

export const getMyEnrollments = () =>
  axiosInstance.get("/enrollments/my-courses");

export const unenrollFromCourse = (courseId) =>
  axiosInstance.delete(`/enrollments/unenroll/${courseId}`);
