import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
} from "react";
import { jwtDecode } from "jwt-decode";

const AuthContext = createContext({
  user: null,
  login: () => {},
  logout: () => {},
  showWarning: false,
  stayLoggedIn: () => {},
  updateAvatar: () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const token = localStorage.getItem("token");
    if (!token) return null;

    try {
      const decoded = jwtDecode(token);
      if (decoded.exp * 1000 > Date.now()) {
        return { token, ...decoded };
      }
      localStorage.removeItem("token");
      return null;
    } catch (error) {
      console.error("Invalid token:", error);
      localStorage.removeItem("token");
      return null;
    }
  });

  const [showWarning, setShowWarning] = useState(false);

  const INACTIVITY_LIMIT = 15 * 60 * 1000; // 15 minutes
  const WARNING_TIME = 1 * 60 * 1000; // 1 minute before logout

  const activityTimeout = useRef(null);
  const warningTimeout = useRef(null);

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
    setShowWarning(false);
  };

  const login = (userData) => {
    localStorage.setItem("token", userData.token);
    const decoded = jwtDecode(userData.token);
    setUser({ token: userData.token, ...decoded });
  };

  const resetInactivityTimer = () => {
    if (activityTimeout.current) clearTimeout(activityTimeout.current);
    if (warningTimeout.current) clearTimeout(warningTimeout.current);
    setShowWarning(false);

    warningTimeout.current = setTimeout(() => {
      setShowWarning(true);
    }, INACTIVITY_LIMIT - WARNING_TIME);

    activityTimeout.current = setTimeout(() => {
      logout();
    }, INACTIVITY_LIMIT);
  };

  const stayLoggedIn = () => {
    resetInactivityTimer(); // extend session
    setShowWarning(false);
  };

  const updateAvatar = (newAvatarUrl) => {
    setUser((prevUser) => {
      if (!prevUser) return null;

      const updatedUser = {
        ...prevUser,
        avatar: newAvatarUrl, // or whatever key you're using
      };

      // Update token in localStorage if necessary
      localStorage.setItem("token", updatedUser.token); // Only if the token hasn't changed

      return updatedUser;
    });
  };

  useEffect(() => {
    if (!user) return;

    const handleActivity = () => resetInactivityTimer();

    window.addEventListener("mousemove", handleActivity);
    window.addEventListener("keydown", handleActivity);
    window.addEventListener("scroll", handleActivity);
    window.addEventListener("click", handleActivity);

    resetInactivityTimer();

    return () => {
      clearTimeout(activityTimeout.current);
      clearTimeout(warningTimeout.current);
      window.removeEventListener("mousemove", handleActivity);
      window.removeEventListener("keydown", handleActivity);
      window.removeEventListener("scroll", handleActivity);
      window.removeEventListener("click", handleActivity);
    };
  }, [user]);

  return (
    <AuthContext.Provider
      value={{ user, login, logout, showWarning, stayLoggedIn, updateAvatar }}
    >
      {children}
    </AuthContext.Provider>
  );
};
