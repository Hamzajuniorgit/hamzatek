import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";
import AdminDashboard2 from "./pages/AdminDashboard2";
import StudentDashboard from "./pages/StudentDashboard";
import TeacherDashboard from "./pages/TeacherDashboard";
import { AuthProvider } from "./context/AuthContext";
import PrivateRoute from "./components/PrivateRoute";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Home from "./pages/Home";
import Courses from "./components/admin/Courses";
import Teachers from "./components/admin/Teachers";
import Students from "./components/admin/Students";
import DashboardContent from "./components/admin/DashboardContent";
import InactivityWarning from "./components/InactivityWarning";
import MyCourses from "./pages/MyCourses";
import StudentCourseDetails from "./pages/StudentCourseDetails";
import CourseList from "./pages/CourseList";
import StudentCoursePage from "./pages/StudentCoursePage";
import WelcomeMessage from "./components/WelcomeMessage";

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <Navbar />

        <ToastContainer />
        <InactivityWarning />
        <Routes>
          {/* Protected Routes */}
          <Route
            path="/dashboard"
            element={<PrivateRoute allowedRoles={["admin", "user"]} />}
          >
            <Route path="" element={<Dashboard />} />
          </Route>
          <Route
            path="/admin"
            element={<PrivateRoute allowedRoles={["admin"]} />}
          >
            <Route path="" element={<AdminDashboard2 />} />
            <Route path="courses" element={<Courses />} />
            <Route path="teachers" element={<Teachers />} />
            <Route path="students" element={<Students />} />
          </Route>
          <Route
            path="/student-dashboard"
            element={<PrivateRoute allowedRoles={["student"]} />}
          >
            <Route path="" element={<StudentDashboard />} />
            <Route path="my-courses" element={<MyCourses />} />
            <Route path="courses/:id" element={<StudentCoursePage />} />
          </Route>
          <Route
            path="/teacher-dashboard"
            element={<PrivateRoute allowedRoles={["teacher"]} />}
          >
            <Route path="" element={<TeacherDashboard />} />
          </Route>

          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Footer />
      </Router>
    </AuthProvider>
  );
};

export default App;
