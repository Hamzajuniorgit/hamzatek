// src/components/CourseCard.jsx
import React from "react";

function CourseCard({
  course,
  isEnrolled,
  onEnrollClick,
  onUnenrollClick,
  onViewDetails,
}) {
  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h2 className="text-xl font-semibold text-gray-800">{course.title}</h2>
      <p className="text-gray-600">By: {course.teacher?.name || "Unknown"}</p>
      <p className="text-sm text-gray-500 mb-2">Level: {course.level}</p>
      <p className="text-sm text-gray-500 mb-4">Price: ${course.price}</p>

      <div className="flex justify-between items-center">
        {isEnrolled ? (
          <button
            onClick={() => onUnenrollClick(course)}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
          >
            Unenroll
          </button>
        ) : (
          <button
            onClick={() => onEnrollClick(course)}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
          >
            Enroll
          </button>
        )}

        <button
          onClick={() => onViewDetails(course)}
          className="text-blue-600 hover:underline"
        >
          View Details
        </button>
      </div>
    </div>
  );
}

export default CourseCard;
