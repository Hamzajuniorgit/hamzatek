import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Menu, X } from "lucide-react";
import axiosInstance from "../services/axiosInstance";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const profileRef = useRef(null);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [previewAvatar, setPreviewAvatar] = useState(user?.avatar || null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setIsProfileOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const roleDashboardPaths = {
    admin: "/admin",
    teacher: "/teacher-dashboard",
    student: "/student-dashboard",
  };

  const isActive = (path) => location.pathname.startsWith(path);

  const handleAvatarChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("avatar", file);

    try {
      const response = await axiosInstance.post(
        "http://localhost:5173/api/users/upload-avatar",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${user.token}`,
          },
        }
      );

      // Assuming your server returns: /uploads/avatars/filename.jpeg
      const newAvatarPath = response.data.avatar;

      // If you're serving static files from backend correctly,
      // and your backend base URL is http://localhost:5173
      const fullUrl = `http://localhost:5173${newAvatarPath}`;
      setPreviewAvatar(fullUrl);
    } catch (error) {
      console.error("Error uploading avatar:", error);
    }
  };

  return (
    <nav className="bg-white border-b border-gray-200 shadow-md relative z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="text-3xl font-bold text-blue-600">
          E<span className="text-xl font-serif text-black">-</span>
          <span className="text-xl font-bold text-green-600 ">Learning</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-6">
          <Link
            to="/"
            className={`${
              isActive("/") ? "text-blue-700 font-semibold" : "text-gray-600"
            } hover:text-blue-600`}
          >
            Home
          </Link>

          {user ? (
            <>
              {/* Profile Dropdown */}
              <div className="relative" ref={profileRef}>
                <button
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="focus:outline-none"
                >
                  <img
                    src={previewAvatar || "/default-avatar.jpeg"}
                    alt="avatar"
                    className="w-8 h-8 rounded-full object-cover border border-gray-300"
                  />
                </button>

                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white border rounded-md shadow-lg py-3 px-4 z-50">
                    <div className="flex items-center gap-3">
                      <img
                        src={previewAvatar || "/default-avatar.jpeg"}
                        alt="profile"
                        className="w-12 h-12 rounded-full object-cover border"
                      />

                      <div>
                        <p className="text-sm font-semibold">{user.name}</p>
                        <p className="text-xs text-gray-500 capitalize">
                          {user.role}
                        </p>
                      </div>
                    </div>

                    <div className="mt-3">
                      <label
                        htmlFor="avatar-upload"
                        className="block text-xs font-medium text-gray-600 mb-1"
                      >
                        Update Avatar
                      </label>
                      <label
                        htmlFor="avatar-upload"
                        className="cursor-pointer bg-gray-100 hover:bg-gray-200 text-sm text-gray-700 px-3 py-1 rounded"
                      >
                        Choose File
                      </label>
                      <input
                        id="avatar-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarChange}
                        className="hidden"
                      />
                    </div>

                    <Link
                      to={roleDashboardPaths[user.role]}
                      onClick={() => setIsProfileOpen(false)}
                      className="block mt-3 px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Dashboard
                    </Link>

                    <button
                      onClick={() => {
                        handleLogout();
                        setIsProfileOpen(false);
                      }}
                      className="w-full text-left mt-2 px-3 py-2 rounded-md text-sm text-red-600 hover:bg-gray-100"
                    >
                      Logout
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className={`${
                  isActive("/login")
                    ? "text-blue-700 font-semibold"
                    : "text-gray-600"
                } hover:text-blue-600`}
              >
                Login
              </Link>
              <Link
                to="/register"
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
              >
                Sign Up
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <div className="md:hidden">
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu (same as before) */}
      {isMobileMenuOpen && (
        <div className="md:hidden px-4 pb-4 space-y-2">
          <Link
            to="/"
            onClick={() => setIsMobileMenuOpen(false)}
            className={`block ${
              isActive("/") ? "text-blue-700 font-semibold" : "text-gray-600"
            } hover:text-blue-600`}
          >
            Home
          </Link>

          {user ? (
            <>
              <Link
                to={roleDashboardPaths[user.role]}
                onClick={() => setIsMobileMenuOpen(false)}
                className="block text-gray-600 hover:text-blue-600"
              >
                Dashboard
              </Link>
              <button
                onClick={() => {
                  handleLogout();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-left bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`block ${
                  isActive("/login")
                    ? "text-blue-700 font-semibold"
                    : "text-gray-600"
                } hover:text-blue-600`}
              >
                Login
              </Link>
              <Link
                to="/register"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
              >
                Sign Up
              </Link>
            </>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
