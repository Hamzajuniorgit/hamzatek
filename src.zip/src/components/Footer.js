import React from 'react';
import { Link } from 'react-router-dom';
import { FaFacebook, FaTwitter, FaInstagram } from 'react-icons/fa';
import { AiFillLinkedin } from 'react-icons/ai';
import { MdEmail } from 'react-icons/md';
import { BsFillTelephoneFill } from 'react-icons/bs';
import { HiLocationMarker } from 'react-icons/hi';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const Footer = () => {
    const { user } = useAuth();
    const handleLogout = () => {
        toast.success('Logged out successfully');
    };
    return (
        <footer className="bg-gray-800 text-white py-4">
            <div className="container mx-auto flex flex-col items-center">
                <div className="flex space-x-4 mb-4">
                    <Link to="/about" className="text-gray-300 hover:text-white">About Us</Link>
                    <Link to="/contact" className="text-gray-300 hover:text-white">Contact Us</Link>
                    <Link to="/privacy" className="text-gray-300 hover:text-white">Privacy Policy</Link>
                    <Link to="/terms" className="text-gray-300 hover:text-white">Terms of Service</Link>
                </div>
                <div className="flex space-x-4 mb-4">
                    <a href="#" className="text-gray-300 hover:text-white"><FaFacebook /></a>
                    <a href="#" className="text-gray-300 hover:text-white"><FaTwitter /></a>
                    <a href="#" className="text-gray-300 hover:text-white"><FaInstagram /></a>
                    <a href="#" className="text-gray-300 hover:text-white"><AiFillLinkedin /></a>
                </div>
                <div className="flex space-x-4 mb-4">
                    <a href="#" className="text-gray-300 hover:text-white"><MdEmail /></a>
                    <a href="#" className="text-gray-300 hover:text-white"><BsFillTelephoneFill /></a>
                    <a href="#" className="text-gray-300 hover:text-white"><HiLocationMarker /></a>
                </div>
                <p className="text-sm text-gray-400">
                    &copy; {new Date().getFullYear()} Your Company Name. All rights reserved.
                </p>
            </div>
        </footer>
    );
};

export default Footer;
